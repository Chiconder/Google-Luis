let indiceActual = 0;
cambiarImagen(0); // Muestra la primera imagen inmediatamente

setInterval(function() {
    cambiarImagen(1); // Cambia a la siguiente imagen cada 0.5 segundos
}, 3000); // 5000 milisegundos = 5 segundos

function cambiarImagen(direccion) {
    const imagenes = document.querySelectorAll('.carrusel-imagenes img');
    imagenes[indiceActual].style.display = 'none'; // Oculta la imagen actual
    indiceActual += direccion;

    // Ciclo de imágenes
    if (indiceActual >= imagenes.length) indiceActual = 0;
    else if (indiceActual < 0) indiceActual = imagenes.length - 1;

    imagenes[indiceActual].style.display = 'block'; // Muestra la nueva imagen activa
}

document.getElementById('imagenBienvenida').addEventListener('click', function() {
    this.classList.toggle('mostrar-overlay');
});

function verImagenes() {
    // Aquí colocarías tu código o redireccionamiento para mostrar imágenes
    alert("Mostrando imágenes...");
}

function contactar() {
    // Aquí colocarías tu código o redireccionamiento para la sección de contacto
    alert("Sección de contacto...");
}
